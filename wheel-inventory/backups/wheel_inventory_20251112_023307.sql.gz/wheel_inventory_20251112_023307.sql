--
-- PostgreSQL database dump
--

\restrict qGuXdcBHHhpIKLup3eLBzd33tGZWm9mG8KIVa6NozEpCGZQrz9HSWpmhXm2jxdh

-- Dumped from database version 15.14
-- Dumped by pg_dump version 15.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: wheeluser
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO wheeluser;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: wheel_audit; Type: TABLE; Schema: public; Owner: wheeluser
--

CREATE TABLE public.wheel_audit (
    audit_id integer NOT NULL,
    wheel_id integer,
    action character varying(20),
    old_data jsonb,
    new_data jsonb,
    changed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.wheel_audit OWNER TO wheeluser;

--
-- Name: wheel_audit_audit_id_seq; Type: SEQUENCE; Schema: public; Owner: wheeluser
--

CREATE SEQUENCE public.wheel_audit_audit_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.wheel_audit_audit_id_seq OWNER TO wheeluser;

--
-- Name: wheel_audit_audit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: wheeluser
--

ALTER SEQUENCE public.wheel_audit_audit_id_seq OWNED BY public.wheel_audit.audit_id;


--
-- Name: wheels; Type: TABLE; Schema: public; Owner: wheeluser
--

CREATE TABLE public.wheels (
    id integer NOT NULL,
    part_number character varying(100) NOT NULL,
    size character varying(50) NOT NULL,
    "offset" character varying(20),
    model character varying(100) NOT NULL,
    year integer NOT NULL,
    finish character varying(100),
    grade character varying(50),
    retail_price numeric(10,2) NOT NULL,
    sku character varying(200) NOT NULL,
    status character varying(20) DEFAULT 'available'::character varying,
    sold_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.wheels OWNER TO wheeluser;

--
-- Name: wheels_id_seq; Type: SEQUENCE; Schema: public; Owner: wheeluser
--

CREATE SEQUENCE public.wheels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.wheels_id_seq OWNER TO wheeluser;

--
-- Name: wheels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: wheeluser
--

ALTER SEQUENCE public.wheels_id_seq OWNED BY public.wheels.id;


--
-- Name: wheel_audit audit_id; Type: DEFAULT; Schema: public; Owner: wheeluser
--

ALTER TABLE ONLY public.wheel_audit ALTER COLUMN audit_id SET DEFAULT nextval('public.wheel_audit_audit_id_seq'::regclass);


--
-- Name: wheels id; Type: DEFAULT; Schema: public; Owner: wheeluser
--

ALTER TABLE ONLY public.wheels ALTER COLUMN id SET DEFAULT nextval('public.wheels_id_seq'::regclass);


--
-- Data for Name: wheel_audit; Type: TABLE DATA; Schema: public; Owner: wheeluser
--

COPY public.wheel_audit (audit_id, wheel_id, action, old_data, new_data, changed_at) FROM stdin;
1	4	INSERT	\N	{"id": 4, "sku": "1-1-1B", "size": "1", "year": 1, "grade": "B", "model": "1", "finish": "1", "offset": "+1", "status": "available", "sold_at": null, "created_at": "2025-11-11T22:55:04.980Z", "updated_at": "2025-11-11T22:55:04.980Z", "part_number": "1", "retail_price": "1.00"}	2025-11-11 22:55:04.994353
2	5	INSERT	\N	{"id": 5, "sku": "1-1-1B-2", "size": "1", "year": 1, "grade": "B", "model": "1", "finish": "1", "offset": "+1", "status": "available", "sold_at": null, "created_at": "2025-11-11T22:55:14.263Z", "updated_at": "2025-11-11T22:55:14.263Z", "part_number": "1", "retail_price": "1.00"}	2025-11-11 22:55:14.269141
3	5	DELETE	{"id": 5, "sku": "1-1-1B-2", "size": "1", "year": 1, "grade": "B", "model": "1", "finish": "1", "offset": "+1", "status": "available", "sold_at": null, "created_at": "2025-11-11T22:55:14.263Z", "updated_at": "2025-11-11T22:55:14.263Z", "part_number": "1", "retail_price": "1.00"}	\N	2025-11-11 22:55:18.404527
4	4	DELETE	{"id": 4, "sku": "1-1-1B", "size": "1", "year": 1, "grade": "B", "model": "1", "finish": "1", "offset": "+1", "status": "available", "sold_at": null, "created_at": "2025-11-11T22:55:04.980Z", "updated_at": "2025-11-11T22:55:04.980Z", "part_number": "1", "retail_price": "1.00"}	\N	2025-11-11 22:55:20.667168
5	6	INSERT	\N	{"id": 6, "sku": "000212120015", "size": "21", "year": 21, "grade": "B", "model": "21", "finish": "21", "offset": "+21", "status": "available", "sold_at": null, "created_at": "2025-11-11T23:32:13.498Z", "updated_at": "2025-11-11T23:32:13.498Z", "part_number": "21", "retail_price": "21.00"}	2025-11-11 23:32:13.513663
6	7	INSERT	\N	{"id": 7, "sku": "281112510018", "size": "19x7.5", "year": 2025, "grade": "A", "model": "Forester", "finish": "Gray Machined", "offset": "+55", "status": "available", "sold_at": null, "created_at": "2025-11-11T23:47:42.235Z", "updated_at": "2025-11-11T23:47:42.235Z", "part_number": "28111SL060`", "retail_price": "325.00"}	2025-11-11 23:47:42.256022
7	8	INSERT	\N	{"id": 8, "sku": "281112510025", "size": "19x7.5", "year": 2025, "grade": "A", "model": "Forester Touring", "finish": "Gray Machined", "offset": "+55", "status": "available", "sold_at": null, "created_at": "2025-11-11T23:48:36.800Z", "updated_at": "2025-11-11T23:48:36.800Z", "part_number": "28111SL060", "retail_price": "325.00"}	2025-11-11 23:48:36.819558
8	9	INSERT	\N	{"id": 9, "sku": "281112510032", "size": "19.7.5", "year": 2025, "grade": "A", "model": "Forester Touring", "finish": "Gray Machined", "offset": "+55", "status": "available", "sold_at": null, "created_at": "2025-11-11T23:49:07.935Z", "updated_at": "2025-11-11T23:49:07.935Z", "part_number": "28111SL060", "retail_price": "325.00"}	2025-11-11 23:49:07.952971
9	6	DELETE	{"id": 6, "sku": "000212120015", "size": "21", "year": 21, "grade": "B", "model": "21", "finish": "21", "offset": "+21", "status": "available", "sold_at": null, "created_at": "2025-11-11T23:32:13.498Z", "updated_at": "2025-11-11T23:32:13.498Z", "part_number": "21", "retail_price": "21.00"}	\N	2025-11-11 23:49:11.752144
10	1	DELETE	{"id": 1, "sku": "68811-17x7.5-2018A", "size": "17x7.5", "year": 2018, "grade": "A", "model": "Crosstrek", "finish": "Silver", "offset": "+55", "status": "available", "sold_at": null, "created_at": "2025-11-11T22:53:35.093Z", "updated_at": "2025-11-11T22:53:35.093Z", "part_number": "68811", "retail_price": "150.00"}	\N	2025-11-11 23:49:14.020318
11	2	DELETE	{"id": 2, "sku": "68812-18x8.5-2020A", "size": "18x8.5", "year": 2020, "grade": "A", "model": "WRX", "finish": "Black", "offset": "+48", "status": "available", "sold_at": null, "created_at": "2025-11-11T22:53:35.093Z", "updated_at": "2025-11-11T22:53:35.093Z", "part_number": "68812", "retail_price": "200.00"}	\N	2025-11-11 23:49:16.232178
12	9	DELETE	{"id": 9, "sku": "281112510032", "size": "19.7.5", "year": 2025, "grade": "A", "model": "Forester Touring", "finish": "Gray Machined", "offset": "+55", "status": "available", "sold_at": null, "created_at": "2025-11-11T23:49:07.935Z", "updated_at": "2025-11-11T23:49:07.935Z", "part_number": "28111SL060", "retail_price": "325.00"}	\N	2025-11-11 23:49:34.58734
13	10	INSERT	\N	{"id": 10, "sku": "281112510032", "size": "19x7.5", "year": 2025, "grade": "A", "model": "Forester Touring", "finish": "Gray Machined", "offset": "+55", "status": "available", "sold_at": null, "created_at": "2025-11-11T23:50:06.620Z", "updated_at": "2025-11-11T23:50:06.620Z", "part_number": "28111SL060", "retail_price": "325.00"}	2025-11-11 23:50:06.638183
14	8	DELETE	{"id": 8, "sku": "281112510025", "size": "19x7.5", "year": 2025, "grade": "A", "model": "Forester Touring", "finish": "Gray Machined", "offset": "+55", "status": "available", "sold_at": null, "created_at": "2025-11-11T23:48:36.800Z", "updated_at": "2025-11-11T23:48:36.800Z", "part_number": "28111SL060", "retail_price": "325.00"}	\N	2025-11-11 23:50:11.685659
15	7	DELETE	{"id": 7, "sku": "281112510018", "size": "19x7.5", "year": 2025, "grade": "A", "model": "Forester", "finish": "Gray Machined", "offset": "+55", "status": "available", "sold_at": null, "created_at": "2025-11-11T23:47:42.235Z", "updated_at": "2025-11-11T23:47:42.235Z", "part_number": "28111SL060`", "retail_price": "325.00"}	\N	2025-11-11 23:50:15.131037
16	11	INSERT	\N	{"id": 11, "sku": "281112510049", "size": "19x7.5", "year": 2025, "grade": "A", "model": "Forester Touring", "finish": "Gray Machined", "offset": "+55", "status": "available", "sold_at": null, "created_at": "2025-11-11T23:50:38.469Z", "updated_at": "2025-11-11T23:50:38.469Z", "part_number": "28111SL060", "retail_price": "325.00"}	2025-11-11 23:50:38.474968
17	10	UPDATE	{"id": 10, "sku": "281112510032", "size": "19x7.5", "year": 2025, "grade": "A", "model": "Forester Touring", "finish": "Gray Machined", "offset": "+55", "status": "available", "sold_at": null, "created_at": "2025-11-11T23:50:06.620Z", "updated_at": "2025-11-11T23:50:06.620Z", "part_number": "28111SL060", "retail_price": "325.00"}	{"id": 10, "sku": "281112510032", "size": "19x7.5", "year": 2025, "grade": "A", "model": "Forester Touring", "finish": "Gray Machined", "offset": "+55", "status": "sold", "sold_at": "2025-11-11T23:50:41.930Z", "created_at": "2025-11-11T23:50:06.620Z", "updated_at": "2025-11-11T23:50:41.930Z", "part_number": "28111SL060", "retail_price": "325.00"}	2025-11-11 23:50:41.940846
18	10	UPDATE	{"id": 10, "sku": "281112510032", "size": "19x7.5", "year": 2025, "grade": "A", "model": "Forester Touring", "finish": "Gray Machined", "offset": "+55", "status": "sold", "sold_at": "2025-11-11T23:50:41.930Z", "created_at": "2025-11-11T23:50:06.620Z", "updated_at": "2025-11-11T23:50:41.930Z", "part_number": "28111SL060", "retail_price": "325.00"}	{"id": 10, "sku": "281112510032", "size": "19x7.5", "year": 2025, "grade": "A", "model": "Forester Touring", "finish": "Gray Machined", "offset": "+55", "status": "available", "sold_at": null, "created_at": "2025-11-11T23:50:06.620Z", "updated_at": "2025-11-11T23:50:48.515Z", "part_number": "28111SL060", "retail_price": "325.00"}	2025-11-11 23:50:48.519275
\.


--
-- Data for Name: wheels; Type: TABLE DATA; Schema: public; Owner: wheeluser
--

COPY public.wheels (id, part_number, size, "offset", model, year, finish, grade, retail_price, sku, status, sold_at, created_at, updated_at) FROM stdin;
3	68813	19x8.5	+55	Forester	2021	Silver	B	175.00	68813-19x8.5-2021B	sold	\N	2025-11-11 22:53:35.093783	2025-11-11 22:53:35.093783
11	28111SL060	19x7.5	+55	Forester Touring	2025	Gray Machined	A	325.00	281112510049	available	\N	2025-11-11 23:50:38.469669	2025-11-11 23:50:38.469669
10	28111SL060	19x7.5	+55	Forester Touring	2025	Gray Machined	A	325.00	281112510032	available	\N	2025-11-11 23:50:06.620545	2025-11-11 23:50:48.515047
\.


--
-- Name: wheel_audit_audit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wheeluser
--

SELECT pg_catalog.setval('public.wheel_audit_audit_id_seq', 18, true);


--
-- Name: wheels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wheeluser
--

SELECT pg_catalog.setval('public.wheels_id_seq', 11, true);


--
-- Name: wheel_audit wheel_audit_pkey; Type: CONSTRAINT; Schema: public; Owner: wheeluser
--

ALTER TABLE ONLY public.wheel_audit
    ADD CONSTRAINT wheel_audit_pkey PRIMARY KEY (audit_id);


--
-- Name: wheels wheels_pkey; Type: CONSTRAINT; Schema: public; Owner: wheeluser
--

ALTER TABLE ONLY public.wheels
    ADD CONSTRAINT wheels_pkey PRIMARY KEY (id);


--
-- Name: wheels wheels_sku_key; Type: CONSTRAINT; Schema: public; Owner: wheeluser
--

ALTER TABLE ONLY public.wheels
    ADD CONSTRAINT wheels_sku_key UNIQUE (sku);


--
-- Name: idx_audit_changed_at; Type: INDEX; Schema: public; Owner: wheeluser
--

CREATE INDEX idx_audit_changed_at ON public.wheel_audit USING btree (changed_at DESC);


--
-- Name: idx_audit_wheel_id; Type: INDEX; Schema: public; Owner: wheeluser
--

CREATE INDEX idx_audit_wheel_id ON public.wheel_audit USING btree (wheel_id);


--
-- Name: idx_wheels_created_at; Type: INDEX; Schema: public; Owner: wheeluser
--

CREATE INDEX idx_wheels_created_at ON public.wheels USING btree (created_at DESC);


--
-- Name: idx_wheels_model; Type: INDEX; Schema: public; Owner: wheeluser
--

CREATE INDEX idx_wheels_model ON public.wheels USING btree (model);


--
-- Name: idx_wheels_model_year; Type: INDEX; Schema: public; Owner: wheeluser
--

CREATE INDEX idx_wheels_model_year ON public.wheels USING btree (model, year);


--
-- Name: idx_wheels_part_number; Type: INDEX; Schema: public; Owner: wheeluser
--

CREATE INDEX idx_wheels_part_number ON public.wheels USING btree (part_number);


--
-- Name: idx_wheels_sku; Type: INDEX; Schema: public; Owner: wheeluser
--

CREATE INDEX idx_wheels_sku ON public.wheels USING btree (sku);


--
-- Name: idx_wheels_sold_at; Type: INDEX; Schema: public; Owner: wheeluser
--

CREATE INDEX idx_wheels_sold_at ON public.wheels USING btree (sold_at DESC);


--
-- Name: idx_wheels_status; Type: INDEX; Schema: public; Owner: wheeluser
--

CREATE INDEX idx_wheels_status ON public.wheels USING btree (status);


--
-- Name: idx_wheels_status_created; Type: INDEX; Schema: public; Owner: wheeluser
--

CREATE INDEX idx_wheels_status_created ON public.wheels USING btree (status, created_at DESC);


--
-- Name: idx_wheels_year; Type: INDEX; Schema: public; Owner: wheeluser
--

CREATE INDEX idx_wheels_year ON public.wheels USING btree (year);


--
-- Name: wheels update_wheels_updated_at; Type: TRIGGER; Schema: public; Owner: wheeluser
--

CREATE TRIGGER update_wheels_updated_at BEFORE UPDATE ON public.wheels FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- PostgreSQL database dump complete
--

\unrestrict qGuXdcBHHhpIKLup3eLBzd33tGZWm9mG8KIVa6NozEpCGZQrz9HSWpmhXm2jxdh

